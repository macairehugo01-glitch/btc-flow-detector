'use client'

import { useEffect, useRef, useCallback } from 'react'
import { useMarketStore } from '@/store/useMarketStore'
import {
  createChart,
  ColorType,
  LineStyle,
  type IChartApi,
  type ISeriesApi,
  type LineData,
  type HistogramData,
  type Time,
} from 'lightweight-charts'

export function OIChart() {
  const containerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const oiSeriesRef = useRef<ISeriesApi<'Line'> | null>(null)
  const oiDeltaRef = useRef<ISeriesApi<'Histogram'> | null>(null)

  const { oi } = useMarketStore()

  useEffect(() => {
    if (!containerRef.current) return

    const chart = createChart(containerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#8892a4',
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10,
      },
      grid: {
        vertLines: { color: '#1e2130', style: LineStyle.Dotted },
        horzLines: { color: '#1e2130', style: LineStyle.Dotted },
      },
      rightPriceScale: { borderColor: '#1e2130', textColor: '#8892a4' },
      timeScale: { borderColor: '#1e2130', textColor: '#8892a4', timeVisible: true },
      crosshair: {
        vertLine: { color: '#4a5568', width: 1, style: LineStyle.Dashed, labelBackgroundColor: '#13151c' },
        horzLine: { color: '#4a5568', width: 1, style: LineStyle.Dashed, labelBackgroundColor: '#13151c' },
      },
    })

    // OI line
    const oiSeries = chart.addLineSeries({
      color: '#4dabf7',
      lineWidth: 2,
      title: 'OI',
      priceLineVisible: false,
      lastValueVisible: true,
    })

    // OI delta histogram (change per bar)
    const oiDelta = chart.addHistogramSeries({
      priceScaleId: 'delta',
      priceFormat: { type: 'percent' },
      lastValueVisible: false,
      priceLineVisible: false,
    })

    chart.priceScale('delta').applyOptions({
      scaleMargins: { top: 0.8, bottom: 0 },
      borderVisible: false,
    })

    chartRef.current = chart
    oiSeriesRef.current = oiSeries
    oiDeltaRef.current = oiDelta

    const observer = new ResizeObserver(() => {
      if (containerRef.current) {
        chart.applyOptions({ width: containerRef.current.clientWidth })
      }
    })
    observer.observe(containerRef.current)

    return () => {
      observer.disconnect()
      chart.remove()
    }
  }, [])

  useEffect(() => {
    if (!oiSeriesRef.current || !oiDeltaRef.current || oi.length === 0) return

    const lineData: LineData[] = oi.map(s => ({
      time: s.time as Time,
      value: s.openInterest,
    }))
    oiSeriesRef.current.setData(lineData)

    // Histogram: color by OI change direction
    const histData: HistogramData[] = oi.map((s, i) => {
      const prev = oi[i - 1]
      const change = prev ? s.openInterest - prev.openInterest : 0
      return {
        time: s.time as Time,
        value: change,
        color: change >= 0 ? 'rgba(0,212,168,0.5)' : 'rgba(255,71,87,0.5)',
      }
    })
    oiDeltaRef.current.setData(histData)
  }, [oi])

  return (
    <div
      className="rounded-xl overflow-hidden flex flex-col"
      style={{ background: 'var(--bg-card)', border: '1px solid var(--bg-border)' }}
    >
      <div
        className="flex items-center justify-between px-4 py-3 border-b"
        style={{ borderColor: 'var(--bg-border)' }}
      >
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono uppercase tracking-widest" style={{ color: 'var(--text-muted)' }}>
            Open Interest
          </span>
          <div className="flex items-center gap-3 text-xs font-mono">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full inline-block" style={{ background: 'var(--accent-green)' }} />
              <span style={{ color: 'var(--text-muted)' }}>Build-up</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full inline-block" style={{ background: 'var(--accent-red)' }} />
              <span style={{ color: 'var(--text-muted)' }}>Unwind</span>
            </span>
          </div>
        </div>
      </div>
      <div ref={containerRef} className="w-full" style={{ height: '160px' }} />
    </div>
  )
}
