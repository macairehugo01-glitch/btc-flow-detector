'use client'

import { useEffect, useRef, useCallback } from 'react'
import { useMarketStore } from '@/store/useMarketStore'
import {
  createChart,
  ColorType,
  CrosshairMode,
  LineStyle,
  type IChartApi,
  type ISeriesApi,
  type CandlestickData,
  type LineData,
  type Time,
} from 'lightweight-charts'
import { BarChart2 } from 'lucide-react'

export function PriceChart() {
  const containerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null)
  const vwapSeriesRef = useRef<ISeriesApi<'Line'> | null>(null)

  const { klines, vwap, pattern } = useMarketStore()

  // Init chart once
  useEffect(() => {
    if (!containerRef.current) return

    const chart = createChart(containerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#8892a4',
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 11,
      },
      grid: {
        vertLines: { color: '#1e2130', style: LineStyle.Dotted },
        horzLines: { color: '#1e2130', style: LineStyle.Dotted },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: { color: '#4a5568', width: 1, style: LineStyle.Dashed, labelBackgroundColor: '#13151c' },
        horzLine: { color: '#4a5568', width: 1, style: LineStyle.Dashed, labelBackgroundColor: '#13151c' },
      },
      rightPriceScale: {
        borderColor: '#1e2130',
        textColor: '#8892a4',
      },
      timeScale: {
        borderColor: '#1e2130',
        textColor: '#8892a4',
        timeVisible: true,
        secondsVisible: false,
      },
      handleScroll: true,
      handleScale: true,
    })

    // Candlestick series
    const candleSeries = chart.addCandlestickSeries({
      upColor: '#00d4a8',
      downColor: '#ff4757',
      borderUpColor: '#00d4a8',
      borderDownColor: '#ff4757',
      wickUpColor: '#00d4a8',
      wickDownColor: '#ff4757',
    })

    // VWAP line
    const vwapSeries = chart.addLineSeries({
      color: '#ffd43b',
      lineWidth: 2,
      lineStyle: LineStyle.Dashed,
      title: 'VWAP',
      priceLineVisible: true,
      lastValueVisible: true,
    })

    chartRef.current = chart
    candleSeriesRef.current = candleSeries
    vwapSeriesRef.current = vwapSeries

    // Responsive resize
    const observer = new ResizeObserver(() => {
      if (containerRef.current) {
        chart.applyOptions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight,
        })
      }
    })
    observer.observe(containerRef.current)

    return () => {
      observer.disconnect()
      chart.remove()
      chartRef.current = null
    }
  }, [])

  // Update data when klines/vwap change
  useEffect(() => {
    if (!candleSeriesRef.current || !vwapSeriesRef.current) return

    if (klines.length > 0) {
      const candleData: CandlestickData[] = klines.map(k => ({
        time: k.time as Time,
        open: k.open,
        high: k.high,
        low: k.low,
        close: k.close,
      }))
      candleSeriesRef.current.setData(candleData)
    }

    if (vwap.length > 0) {
      const vwapData: LineData[] = vwap.map(v => ({
        time: v.time as Time,
        value: v.vwap,
      }))
      vwapSeriesRef.current.setData(vwapData)
    }
  }, [klines, vwap])

  // Add signal markers
  useEffect(() => {
    if (!candleSeriesRef.current || !pattern || pattern.signal === 'none') return
    // Markers will be added in future update
  }, [pattern])

  const handleFitContent = useCallback(() => {
    chartRef.current?.timeScale().fitContent()
  }, [])

  return (
    <div
      className="rounded-xl overflow-hidden flex flex-col"
      style={{ background: 'var(--bg-card)', border: '1px solid var(--bg-border)' }}
    >
      {/* Chart header */}
      <div
        className="flex items-center justify-between px-4 py-3 border-b"
        style={{ borderColor: 'var(--bg-border)' }}
      >
        <div className="flex items-center gap-2">
          <BarChart2 size={14} style={{ color: 'var(--accent-green)' }} />
          <span className="text-xs font-mono uppercase tracking-widest" style={{ color: 'var(--text-muted)' }}>
            BTCUSDT Perpetual
          </span>
        </div>
        <div className="flex items-center gap-4">
          {/* Legend */}
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 rounded inline-block" style={{ background: 'var(--accent-yellow)', borderTop: '2px dashed var(--accent-yellow)' }} />
            <span className="text-xs font-mono" style={{ color: 'var(--text-muted)' }}>VWAP</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-sm inline-block" style={{ background: 'var(--accent-green)' }} />
            <span className="text-xs font-mono" style={{ color: 'var(--text-muted)' }}>Haussier</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-sm inline-block" style={{ background: 'var(--accent-red)' }} />
            <span className="text-xs font-mono" style={{ color: 'var(--text-muted)' }}>Baissier</span>
          </div>
          <button
            onClick={handleFitContent}
            className="text-xs font-mono px-2 py-0.5 rounded transition-colors"
            style={{ color: 'var(--text-secondary)', background: 'var(--bg-border)' }}
          >
            Fit
          </button>
        </div>
      </div>

      {/* Chart */}
      <div ref={containerRef} className="w-full" style={{ height: '320px' }} />
    </div>
  )
}
