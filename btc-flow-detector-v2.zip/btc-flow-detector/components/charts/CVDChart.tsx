'use client'

import { useEffect, useRef } from 'react'
import { useMarketStore } from '@/store/useMarketStore'
import {
  createChart,
  ColorType,
  LineStyle,
  type IChartApi,
  type ISeriesApi,
  type LineData,
  type HistogramData,
  type Time,
} from 'lightweight-charts'

export function CVDChart() {
  const containerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const cvdLineRef = useRef<ISeriesApi<'Line'> | null>(null)
  const deltaHistRef = useRef<ISeriesApi<'Histogram'> | null>(null)

  const { cvd } = useMarketStore()

  useEffect(() => {
    if (!containerRef.current) return

    const chart = createChart(containerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#8892a4',
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10,
      },
      grid: {
        vertLines: { color: '#1e2130', style: LineStyle.Dotted },
        horzLines: { color: '#1e2130', style: LineStyle.Dotted },
      },
      rightPriceScale: { borderColor: '#1e2130', textColor: '#8892a4' },
      timeScale: { borderColor: '#1e2130', textColor: '#8892a4', timeVisible: true },
      crosshair: {
        vertLine: { color: '#4a5568', width: 1, style: LineStyle.Dashed, labelBackgroundColor: '#13151c' },
        horzLine: { color: '#4a5568', width: 1, style: LineStyle.Dashed, labelBackgroundColor: '#13151c' },
      },
    })

    // CVD cumulative line
    const cvdLine = chart.addLineSeries({
      color: '#ffd43b',
      lineWidth: 2,
      title: 'CVD',
      priceLineVisible: false,
      lastValueVisible: true,
    })

    // Delta histogram per bar
    const deltaHist = chart.addHistogramSeries({
      priceScaleId: 'delta',
      lastValueVisible: false,
      priceLineVisible: false,
    })

    chart.priceScale('delta').applyOptions({
      scaleMargins: { top: 0.75, bottom: 0 },
      borderVisible: false,
    })

    chartRef.current = chart
    cvdLineRef.current = cvdLine
    deltaHistRef.current = deltaHist

    const observer = new ResizeObserver(() => {
      if (containerRef.current) {
        chart.applyOptions({ width: containerRef.current.clientWidth })
      }
    })
    observer.observe(containerRef.current)

    return () => {
      observer.disconnect()
      chart.remove()
    }
  }, [])

  useEffect(() => {
    if (!cvdLineRef.current || !deltaHistRef.current || cvd.length === 0) return

    // CVD line
    const lineData: LineData[] = cvd.map(b => ({
      time: b.time as Time,
      value: b.cvd,
    }))
    cvdLineRef.current.setData(lineData)

    // Delta histogram
    const histData: HistogramData[] = cvd.map(b => ({
      time: b.time as Time,
      value: b.delta,
      color: b.delta >= 0 ? 'rgba(0,212,168,0.6)' : 'rgba(255,71,87,0.6)',
    }))
    deltaHistRef.current.setData(histData)
  }, [cvd])

  // Latest CVD stats
  const latestCVD = cvd.length > 0 ? cvd[cvd.length - 1] : null
  const prevCVD = cvd.length > 1 ? cvd[cvd.length - 2] : null
  const cvdTrend = latestCVD && prevCVD
    ? latestCVD.cvd > prevCVD.cvd ? 'up' : 'down'
    : null

  return (
    <div
      className="rounded-xl overflow-hidden flex flex-col"
      style={{ background: 'var(--bg-card)', border: '1px solid var(--bg-border)' }}
    >
      <div
        className="flex items-center justify-between px-4 py-3 border-b"
        style={{ borderColor: 'var(--bg-border)' }}
      >
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono uppercase tracking-widest" style={{ color: 'var(--text-muted)' }}>
            CVD — Cumulative Volume Delta
          </span>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono">
          {latestCVD && (
            <span
              className="font-bold"
              style={{ color: cvdTrend === 'up' ? 'var(--accent-green)' : cvdTrend === 'down' ? 'var(--accent-red)' : 'var(--text-muted)' }}
            >
              {cvdTrend === 'up' ? '▲' : cvdTrend === 'down' ? '▼' : '—'}{' '}
              {latestCVD.cvd.toFixed(2)}
            </span>
          )}
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full inline-block" style={{ background: 'var(--accent-green)' }} />
            <span style={{ color: 'var(--text-muted)' }}>Buy</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full inline-block" style={{ background: 'var(--accent-red)' }} />
            <span style={{ color: 'var(--text-muted)' }}>Sell</span>
          </span>
        </div>
      </div>
      <div ref={containerRef} className="w-full" style={{ height: '160px' }} />
    </div>
  )
}
