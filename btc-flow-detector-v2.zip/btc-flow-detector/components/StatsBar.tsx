'use client'

import { useMarketStore } from '@/store/useMarketStore'

export function StatsBar() {
  const { ticker, funding, oi } = useMarketStore()

  const latestOI = oi.length > 0 ? oi[oi.length - 1] : null

  const items = [
    {
      label: 'Prix',
      value: ticker ? `$${ticker.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—',
      color: ticker ? (ticker.change24h >= 0 ? 'var(--accent-green)' : 'var(--accent-red)') : 'var(--text-muted)',
    },
    {
      label: '24h',
      value: ticker ? `${ticker.change24h >= 0 ? '+' : ''}${ticker.change24h.toFixed(2)}%` : '—',
      color: ticker ? (ticker.change24h >= 0 ? 'var(--accent-green)' : 'var(--accent-red)') : 'var(--text-muted)',
    },
    {
      label: 'Volume 24h',
      value: ticker ? `$${(ticker.volume24h / 1e9).toFixed(2)}B` : '—',
      color: 'var(--text-secondary)',
    },
    {
      label: 'OI',
      value: latestOI ? `${(latestOI.openInterest / 1000).toFixed(1)}K BTC` : '—',
      color: 'var(--accent-blue)',
    },
    {
      label: 'Funding',
      value: funding ? `${funding.rate >= 0 ? '+' : ''}${funding.rate.toFixed(4)}%` : '—',
      color: funding
        ? funding.rate > 0.01 ? 'var(--accent-green)'
        : funding.rate < -0.01 ? 'var(--accent-red)'
        : 'var(--text-muted)'
        : 'var(--text-muted)',
    },
  ]

  return (
    <div
      className="rounded-xl px-4 py-3 flex items-center justify-between gap-4 flex-wrap"
      style={{ background: 'var(--bg-card)', border: '1px solid var(--bg-border)' }}
    >
      {items.map(item => (
        <div key={item.label} className="flex items-center gap-2">
          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>{item.label}</span>
          <span className="font-mono text-sm font-medium" style={{ color: item.color }}>
            {item.value}
          </span>
        </div>
      ))}
    </div>
  )
}
