'use client'

import { useMarketStore } from '@/store/useMarketStore'
import { Activity, Wifi, WifiOff, RefreshCw } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { fr } from 'date-fns/locale'

const TIMEFRAMES = ['1m', '5m', '15m', '1h'] as const

interface HeaderProps {
  onRefresh: () => void
}

export function Header({ onRefresh }: HeaderProps) {
  const { ticker, timeframe, setTimeframe, isConnected, lastUpdate, thresholds, setThresholds } =
    useMarketStore()

  const priceColor = ticker
    ? ticker.change24h >= 0
      ? 'text-[var(--accent-green)]'
      : 'text-[var(--accent-red)]'
    : 'text-[var(--text-secondary)]'

  return (
    <header
      className="sticky top-0 z-50 border-b"
      style={{
        background: 'rgba(10, 11, 14, 0.95)',
        backdropFilter: 'blur(12px)',
        borderColor: 'var(--bg-border)',
      }}
    >
      <div className="max-w-[1800px] mx-auto px-4 py-3 flex items-center justify-between gap-4 flex-wrap">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <Activity size={20} className="text-[var(--accent-green)]" />
            <span
              className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-[var(--accent-green)]"
              style={{ animation: 'signal-pulse 2s ease-in-out infinite' }}
            />
          </div>
          <div>
            <span className="font-mono font-bold text-sm tracking-wider" style={{ color: 'var(--text-primary)' }}>
              BTC FLOW
            </span>
            <span className="text-xs ml-2" style={{ color: 'var(--text-muted)' }}>
              DETECTOR
            </span>
          </div>
        </div>

        {/* Price display */}
        <div className="flex items-center gap-4">
          <div className="text-center">
            <div className={`font-mono font-bold text-xl ${priceColor}`}>
              {ticker
                ? `$${ticker.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                : '—'
              }
            </div>
            <div className={`font-mono text-xs ${priceColor}`}>
              {ticker
                ? `${ticker.change24h >= 0 ? '+' : ''}${ticker.change24h.toFixed(2)}% 24h`
                : 'BTCUSDT PERP'
              }
            </div>
          </div>

          {ticker && (
            <div className="hidden sm:block text-right">
              <div className="text-xs" style={{ color: 'var(--text-muted)' }}>Vol 24h</div>
              <div className="font-mono text-sm" style={{ color: 'var(--text-secondary)' }}>
                ${(ticker.volume24h / 1e9).toFixed(2)}B
              </div>
            </div>
          )}
        </div>

        {/* Timeframe selector */}
        <div className="flex items-center gap-1 rounded-lg p-1" style={{ background: 'var(--bg-card)', border: '1px solid var(--bg-border)' }}>
          {TIMEFRAMES.map(tf => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className="px-3 py-1 rounded text-xs font-mono font-medium transition-all"
              style={
                timeframe === tf
                  ? { background: 'var(--accent-green)', color: '#0a0b0e' }
                  : { color: 'var(--text-secondary)' }
              }
            >
              {tf}
            </button>
          ))}
        </div>

        {/* Mode + status */}
        <div className="flex items-center gap-3">
          {/* Mode toggle */}
          <button
            onClick={() => setThresholds({ mode: thresholds.mode === 'aggressive' ? 'strict' : 'aggressive' })}
            className="px-3 py-1 rounded text-xs font-mono border transition-all"
            style={{
              borderColor: thresholds.mode === 'strict' ? 'var(--accent-yellow)' : 'var(--bg-border)',
              color: thresholds.mode === 'strict' ? 'var(--accent-yellow)' : 'var(--text-secondary)',
              background: thresholds.mode === 'strict' ? 'rgba(255, 212, 59, 0.08)' : 'transparent',
            }}
          >
            {thresholds.mode === 'strict' ? '🔒 STRICT' : '⚡ AGRESSIF'}
          </button>

          {/* Connection status */}
          <div className="flex items-center gap-1.5">
            {isConnected
              ? <Wifi size={14} className="text-[var(--accent-green)]" />
              : <WifiOff size={14} className="text-[var(--accent-red)]" />
            }
            <span className="text-xs" style={{ color: isConnected ? 'var(--accent-green)' : 'var(--accent-red)' }}>
              {isConnected ? 'LIVE' : 'OFFLINE'}
            </span>
          </div>

          {/* Last update */}
          {lastUpdate && (
            <span className="hidden md:inline text-xs" style={{ color: 'var(--text-muted)' }}>
              {formatDistanceToNow(new Date(lastUpdate), { addSuffix: true, locale: fr })}
            </span>
          )}

          {/* Refresh button */}
          <button
            onClick={onRefresh}
            className="p-1.5 rounded transition-colors"
            style={{ color: 'var(--text-secondary)' }}
            title="Rafraîchir"
          >
            <RefreshCw size={14} />
          </button>
        </div>
      </div>
    </header>
  )
}
