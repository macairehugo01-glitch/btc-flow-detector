/**
 * lib/indicators.ts
 * Pure calculation functions: VWAP, CVD reconstruction, OI analysis
 */

import type { Kline, AggTrade, DeltaBar, OISnapshot, VWAPPoint } from '@/types'

// ============================================================
// VWAP
// ============================================================

/**
 * Calculate session VWAP from klines
 * VWAP = Σ(typical_price × volume) / Σ(volume)
 * Resets every N bars (session) or from beginning of array
 */
export function calculateVWAP(klines: Kline[], sessionBars?: number): VWAPPoint[] {
  if (klines.length === 0) return []

  const result: VWAPPoint[] = []
  let cumulativeTPV = 0  // Σ(typical_price × volume)
  let cumulativeVol = 0  // Σ(volume)

  const startIdx = sessionBars ? Math.max(0, klines.length - sessionBars) : 0

  for (let i = 0; i < klines.length; i++) {
    const k = klines[i]

    // Reset at session boundary
    if (sessionBars && i === startIdx) {
      cumulativeTPV = 0
      cumulativeVol = 0
    }

    if (i < startIdx) {
      // Before session window — still compute but mark as pre-session
      result.push({ time: k.time, vwap: 0 })
      continue
    }

    const typicalPrice = (k.high + k.low + k.close) / 3
    cumulativeTPV += typicalPrice * k.volume
    cumulativeVol += k.volume

    result.push({
      time: k.time,
      vwap: cumulativeVol > 0 ? cumulativeTPV / cumulativeVol : typicalPrice,
    })
  }

  // Filter out pre-session zeroes
  return result.filter(v => v.vwap > 0)
}

/**
 * Get latest VWAP value
 */
export function getLatestVWAP(vwap: VWAPPoint[]): number | null {
  if (vwap.length === 0) return null
  return vwap[vwap.length - 1].vwap
}

// ============================================================
// CVD (Cumulative Volume Delta)
// ============================================================

/**
 * Reconstruct CVD from aggTrades
 * - isBuyerMaker=false => buyer is aggressive => ADD to delta
 * - isBuyerMaker=true  => seller is aggressive => SUBTRACT from delta
 *
 * Groups trades into bars matching kline timeframe
 */
export function calculateCVD(
  trades: AggTrade[],
  klines: Kline[],
): DeltaBar[] {
  if (trades.length === 0 || klines.length === 0) return []

  // Determine bar duration in ms from klines
  const barDurationMs = klines.length >= 2
    ? (klines[1].time - klines[0].time) * 1000
    : 60_000  // default 1m

  // Map each trade to a bar timestamp
  const barMap = new Map<number, { buy: number; sell: number }>()

  for (const trade of trades) {
    // Align trade to its kline bar
    const barTime = Math.floor(trade.time / barDurationMs) * (barDurationMs / 1000)

    if (!barMap.has(barTime)) {
      barMap.set(barTime, { buy: 0, sell: 0 })
    }

    const bar = barMap.get(barTime)!
    if (!trade.isBuyerMaker) {
      // Aggressive buyer
      bar.buy += trade.quantity
    } else {
      // Aggressive seller
      bar.sell += trade.quantity
    }
  }

  // Sort bars and compute cumulative CVD
  const sortedBars = Array.from(barMap.entries()).sort((a, b) => a[0] - b[0])

  let runningCVD = 0
  const result: DeltaBar[] = []

  for (const [time, { buy, sell }] of sortedBars) {
    const delta = buy - sell
    runningCVD += delta
    result.push({
      time,
      buyVolume: buy,
      sellVolume: sell,
      delta,
      cvd: runningCVD,
    })
  }

  return result
}

/**
 * Get recent CVD trend over N bars
 * Returns: 'up' | 'down' | 'flat'
 */
export function getCVDTrend(
  cvdBars: DeltaBar[],
  lookback: number = 10
): 'up' | 'down' | 'flat' {
  if (cvdBars.length < lookback) return 'flat'

  const recent = cvdBars.slice(-lookback)
  const first = recent[0].cvd
  const last = recent[recent.length - 1].cvd
  const change = last - first
  const threshold = Math.abs(first) * 0.05  // 5% of absolute value

  if (change > threshold) return 'up'
  if (change < -threshold) return 'down'
  return 'flat'
}

/**
 * Detect CVD flip — has CVD reversed direction recently?
 */
export function detectCVDFlip(
  cvdBars: DeltaBar[],
  confirmBars: number = 3
): { flippedBullish: boolean; flippedBearish: boolean } {
  if (cvdBars.length < confirmBars * 2) {
    return { flippedBullish: false, flippedBearish: false }
  }

  const recent = cvdBars.slice(-confirmBars)
  const before = cvdBars.slice(-confirmBars * 2, -confirmBars)

  const recentAvgDelta = recent.reduce((s, b) => s + b.delta, 0) / recent.length
  const beforeAvgDelta = before.reduce((s, b) => s + b.delta, 0) / before.length

  return {
    flippedBullish: beforeAvgDelta < 0 && recentAvgDelta > 0,
    flippedBearish: beforeAvgDelta > 0 && recentAvgDelta < 0,
  }
}

// ============================================================
// OPEN INTEREST ANALYSIS
// ============================================================

export interface OIAnalysis {
  current: number
  change1h: number      // % change over last ~12 bars (5m)
  change4h: number      // % change over last ~48 bars (5m)
  trend: 'building' | 'unwinding' | 'stable'
  recentTrend: 'up' | 'down' | 'stable'  // last few bars
}

/**
 * Analyze open interest snapshots
 */
export function analyzeOI(snapshots: OISnapshot[], thresholdPct: number = 0.3): OIAnalysis {
  if (snapshots.length === 0) {
    return { current: 0, change1h: 0, change4h: 0, trend: 'stable', recentTrend: 'stable' }
  }

  const current = snapshots[snapshots.length - 1].openInterest

  const idx1h = Math.max(0, snapshots.length - 12)   // ~1h back on 5m
  const idx4h = Math.max(0, snapshots.length - 48)   // ~4h back on 5m

  const oi1h = snapshots[idx1h].openInterest
  const oi4h = snapshots[idx4h].openInterest

  const change1h = ((current - oi1h) / oi1h) * 100
  const change4h = ((current - oi4h) / oi4h) * 100

  // Recent 3-bar trend
  const recentBars = snapshots.slice(-3)
  const recentDeltas = recentBars.slice(1).map((s, i) =>
    s.openInterest - recentBars[i].openInterest
  )
  const recentSum = recentDeltas.reduce((a, b) => a + b, 0)

  const recentTrend: 'up' | 'down' | 'stable' =
    recentSum > 0 ? 'up' : recentSum < 0 ? 'down' : 'stable'

  // Overall trend
  let trend: 'building' | 'unwinding' | 'stable' = 'stable'
  if (change1h > thresholdPct) trend = 'building'
  else if (change1h < -thresholdPct) trend = 'unwinding'

  return { current, change1h, change4h, trend, recentTrend }
}

// ============================================================
// PRICE ACTION HELPERS
// ============================================================

/**
 * Detect recent impulse move
 */
export function detectImpulse(
  klines: Kline[],
  lookback: number = 10,
  minPct: number = 0.3
): { impulseUp: boolean; impulseDown: boolean; magnitude: number } {
  if (klines.length < lookback) return { impulseUp: false, impulseDown: false, magnitude: 0 }

  const recent = klines.slice(-lookback)
  const firstClose = recent[0].close
  const maxHigh = Math.max(...recent.map(k => k.high))
  const minLow = Math.min(...recent.map(k => k.low))

  const upMove = ((maxHigh - firstClose) / firstClose) * 100
  const downMove = ((firstClose - minLow) / firstClose) * 100

  return {
    impulseUp: upMove >= minPct,
    impulseDown: downMove >= minPct,
    magnitude: Math.max(upMove, downMove),
  }
}

/**
 * Detect price consolidation (low volatility relative to recent range)
 */
export function detectConsolidation(
  klines: Kline[],
  lookback: number = 6,
  maxRangePct: number = 0.15
): boolean {
  if (klines.length < lookback) return false

  const recent = klines.slice(-lookback)
  const high = Math.max(...recent.map(k => k.high))
  const low = Math.min(...recent.map(k => k.low))
  const mid = (high + low) / 2

  const rangePct = ((high - low) / mid) * 100
  return rangePct <= maxRangePct
}

/**
 * Is current price above VWAP?
 */
export function isPriceAboveVWAP(currentPrice: number, vwap: number | null): boolean {
  if (vwap === null) return false
  return currentPrice > vwap
}
