/**
 * lib/db.ts
 * SQLite database — stores detected setups history
 * Designed to be swappable to PostgreSQL later
 */

import Database from 'better-sqlite3'
import path from 'path'
import type { StoredSetup, PatternResult } from '@/types'

const DB_PATH = path.join(process.cwd(), 'data', 'flow.db')

let _db: Database.Database | null = null

function getDB(): Database.Database {
  if (_db) return _db

  // Ensure data directory exists
  const fs = require('fs')
  const dir = path.dirname(DB_PATH)
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true })
  }

  _db = new Database(DB_PATH)
  initSchema(_db)
  return _db
}

function initSchema(db: Database.Database) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS setups (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp   INTEGER NOT NULL,
      marketState TEXT NOT NULL,
      signal      TEXT NOT NULL,
      score       INTEGER NOT NULL,
      confidence  TEXT NOT NULL,
      entryPrice  REAL NOT NULL,
      stopLoss    REAL NOT NULL,
      takeProfit  REAL NOT NULL,
      conditions  TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_setups_timestamp ON setups(timestamp DESC);
    CREATE INDEX IF NOT EXISTS idx_setups_signal ON setups(signal);
  `)
}

// ============================================================
// WRITE
// ============================================================

/**
 * Persist a detected setup
 * Deduplicates: won't insert same marketState within 5 minutes
 */
export function saveSetup(pattern: PatternResult): void {
  if (pattern.signal === 'none') return

  const db = getDB()

  // Dedup check — same setup within 5 min?
  const fiveMinAgo = Math.floor(Date.now() / 1000) - 300
  const existing = db.prepare(`
    SELECT id FROM setups
    WHERE marketState = ? AND timestamp > ?
    LIMIT 1
  `).get(pattern.marketState, fiveMinAgo)

  if (existing) return  // already logged recently

  db.prepare(`
    INSERT INTO setups (timestamp, marketState, signal, score, confidence, entryPrice, stopLoss, takeProfit, conditions)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    Math.floor(Date.now() / 1000),
    pattern.marketState,
    pattern.signal,
    pattern.score,
    pattern.confidence,
    pattern.entryPrice ?? 0,
    pattern.stopLoss ?? 0,
    pattern.takeProfit ?? 0,
    JSON.stringify(pattern.conditions)
  )
}

// ============================================================
// READ
// ============================================================

export function getRecentSetups(limit: number = 50): StoredSetup[] {
  const db = getDB()
  return db.prepare(`
    SELECT * FROM setups ORDER BY timestamp DESC LIMIT ?
  `).all(limit) as StoredSetup[]
}

export function getSetupsBySignal(signal: 'long' | 'short', limit: number = 20): StoredSetup[] {
  const db = getDB()
  return db.prepare(`
    SELECT * FROM setups WHERE signal = ? ORDER BY timestamp DESC LIMIT ?
  `).all(signal, limit) as StoredSetup[]
}

export function getSetupStats(): { total: number; longs: number; shorts: number } {
  const db = getDB()
  const row = db.prepare(`
    SELECT
      COUNT(*) as total,
      SUM(CASE WHEN signal = 'long' THEN 1 ELSE 0 END) as longs,
      SUM(CASE WHEN signal = 'short' THEN 1 ELSE 0 END) as shorts
    FROM setups
  `).get() as { total: number; longs: number; shorts: number }

  return row
}
