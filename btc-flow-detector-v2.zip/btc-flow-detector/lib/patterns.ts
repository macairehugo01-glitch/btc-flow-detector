/**
 * lib/patterns.ts
 * Pattern detection engine — Majority Trap Short, Bullish Reset Long, Continuation
 */

import type {
  Kline,
  DeltaBar,
  OISnapshot,
  VWAPPoint,
  MarketConditions,
  MarketState,
  Signal,
  PatternResult,
  ThresholdConfig,
} from '@/types'
import { DEFAULT_THRESHOLDS } from '@/types'
import {
  getLatestVWAP,
  getCVDTrend,
  detectCVDFlip,
  analyzeOI,
  detectImpulse,
  detectConsolidation,
  isPriceAboveVWAP,
} from './indicators'

// ============================================================
// EVALUATE ALL CONDITIONS
// ============================================================

export function evaluateConditions(
  klines: Kline[],
  cvdBars: DeltaBar[],
  oiSnapshots: OISnapshot[],
  vwapPoints: VWAPPoint[],
  config: ThresholdConfig = DEFAULT_THRESHOLDS
): MarketConditions {
  const currentPrice = klines.length > 0 ? klines[klines.length - 1].close : 0
  const latestVWAP = getLatestVWAP(vwapPoints)

  const cvdTrend = getCVDTrend(cvdBars, 8)
  const cvdFlip = detectCVDFlip(cvdBars, config.cvdFlipBars)

  const oiAnalysis = analyzeOI(oiSnapshots, config.oiBuildUpThresholdPct)

  const impulse = detectImpulse(klines, 12, config.impulseMinPct)

  const aboveVWAP = isPriceAboveVWAP(currentPrice, latestVWAP)

  const consolidating = detectConsolidation(klines, 6, config.consolidationMaxPct)

  return {
    vwapBias: aboveVWAP,
    oiBuildUp: oiAnalysis.trend === 'building',
    oiUnwind: oiAnalysis.trend === 'unwinding',
    oiStabilizing: oiAnalysis.trend === 'stable' && oiAnalysis.recentTrend !== 'down',
    cvdUp: cvdTrend === 'up',
    cvdDown: cvdTrend === 'down',
    cvdFlipBullish: cvdFlip.flippedBullish,
    cvdFlipBearish: cvdFlip.flippedBearish,
    impulseUp: impulse.impulseUp,
    impulseDown: impulse.impulseDown,
    consolidationBelowVWAP: consolidating && !aboveVWAP,
    consolidationAboveVWAP: consolidating && aboveVWAP,
  }
}

// ============================================================
// SCORE SYSTEM
// ============================================================

interface ScoreWeights {
  vwapBias: number
  oiBuildUp: number
  oiUnwind: number
  oiStabilizing: number
  cvdUp: number
  cvdDown: number
  cvdFlipBullish: number
  cvdFlipBearish: number
  impulseUp: number
  impulseDown: number
  consolidationBelowVWAP: number
  consolidationAboveVWAP: number
}

const SCORE_WEIGHTS: ScoreWeights = {
  vwapBias: 2,
  oiBuildUp: 2,
  oiUnwind: 2,
  oiStabilizing: 1,
  cvdUp: 2,
  cvdDown: 2,
  cvdFlipBullish: 2,
  cvdFlipBearish: 2,
  impulseUp: 1,
  impulseDown: 1,
  consolidationBelowVWAP: 1,
  consolidationAboveVWAP: 1,
}

const MAX_POSSIBLE_SCORE = Object.values(SCORE_WEIGHTS).reduce((a, b) => a + b, 0)

function scoreConditions(
  conditions: MarketConditions,
  relevantKeys: (keyof MarketConditions)[]
): number {
  return relevantKeys.reduce((total, key) => {
    return total + (conditions[key] ? SCORE_WEIGHTS[key] : 0)
  }, 0)
}

// ============================================================
// PATTERN: MAJORITY TRAP SHORT
// ============================================================
// Sequence:
//   1. Bullish impulse (price pumped)
//   2. CVD was up (buyers led the move)
//   3. OI built up (new positions opened)
//   4. CVD flips bearish OR CVD now down
//   5. OI starts unwinding
//   6. Price falls below VWAP
//   7. Consolidation below VWAP (distribution zone)
//
// Signal: SHORT

function detectMajorityTrapShort(
  conditions: MarketConditions,
  config: ThresholdConfig
): { score: number; active: boolean } {
  const requiredKeys: (keyof MarketConditions)[] = [
    'cvdFlipBearish',
    'oiUnwind',
    'impulseUp',
    'consolidationBelowVWAP',
  ]

  // All these should be true for the trap to be active
  const active = requiredKeys.every(k => conditions[k])

  // Score also includes supportive conditions
  const scoredKeys: (keyof MarketConditions)[] = [
    'cvdFlipBearish',
    'oiUnwind',
    'impulseUp',
    'consolidationBelowVWAP',
    'cvdDown',
  ]
  // In aggressive mode, partial match counts
  const meetsMinimum = config.mode === 'aggressive'
    ? requiredKeys.filter(k => conditions[k]).length >= 2
    : active

  const score = meetsMinimum ? scoreConditions(conditions, scoredKeys) : 0

  return { score, active: meetsMinimum }
}

// ============================================================
// PATTERN: BULLISH RESET LONG
// ============================================================
// Sequence:
//   1. Recent dump (price dropped)
//   2. CVD was down / bearish
//   3. OI unwound
//   4. Price recovered above VWAP
//   5. OI starts building again
//   6. CVD flips bullish OR stabilizes
//
// Signal: LONG

function detectBullishResetLong(
  conditions: MarketConditions,
  config: ThresholdConfig
): { score: number; active: boolean } {
  const requiredKeys: (keyof MarketConditions)[] = [
    'vwapBias',
    'oiBuildUp',
    'impulseDown',  // there WAS a dump
  ]

  const supportKeys: (keyof MarketConditions)[] = [
    'vwapBias',
    'oiBuildUp',
    'cvdFlipBullish',
    'impulseDown',
    'oiStabilizing',
  ]

  const meetsMinimum = config.mode === 'aggressive'
    ? requiredKeys.filter(k => conditions[k]).length >= 2
    : requiredKeys.every(k => conditions[k])

  const score = meetsMinimum ? scoreConditions(conditions, supportKeys) : 0

  return { score, active: meetsMinimum }
}

// ============================================================
// PATTERN: CONTINUATION LONG
// ============================================================
// Sequence:
//   1. Price above VWAP
//   2. OI building (new buyers)
//   3. CVD trending up
//   4. Clean pullback (consolidation above VWAP)
//
// Signal: LONG

function detectContinuationLong(
  conditions: MarketConditions,
  config: ThresholdConfig
): { score: number; active: boolean } {
  const requiredKeys: (keyof MarketConditions)[] = [
    'vwapBias',
    'cvdUp',
    'oiBuildUp',
  ]

  const supportKeys: (keyof MarketConditions)[] = [
    'vwapBias',
    'cvdUp',
    'oiBuildUp',
    'consolidationAboveVWAP',
    'impulseUp',
  ]

  const meetsMinimum = config.mode === 'aggressive'
    ? requiredKeys.filter(k => conditions[k]).length >= 2
    : requiredKeys.every(k => conditions[k])

  const score = meetsMinimum ? scoreConditions(conditions, supportKeys) : 0

  return { score, active: meetsMinimum }
}

// ============================================================
// MAIN PATTERN DETECTION FUNCTION
// ============================================================

export function detectPattern(
  klines: Kline[],
  cvdBars: DeltaBar[],
  oiSnapshots: OISnapshot[],
  vwapPoints: VWAPPoint[],
  config: ThresholdConfig = DEFAULT_THRESHOLDS
): PatternResult {
  if (klines.length === 0) {
    return buildNeutralResult()
  }

  const conditions = evaluateConditions(klines, cvdBars, oiSnapshots, vwapPoints, config)

  const trapShort = detectMajorityTrapShort(conditions, config)
  const resetLong = detectBullishResetLong(conditions, config)
  const continuationLong = detectContinuationLong(conditions, config)

  const currentPrice = klines[klines.length - 1].close

  // Pick the highest scoring active pattern
  const candidates = [
    { state: 'majority_trap_short' as MarketState, signal: 'short' as Signal, ...trapShort, desc: 'Piège haussier — distribution sous VWAP' },
    { state: 'bullish_reset_long' as MarketState, signal: 'long' as Signal, ...resetLong, desc: 'Reset haussier — reprise après liquidation' },
    { state: 'continuation_long' as MarketState, signal: 'long' as Signal, ...continuationLong, desc: 'Continuation haussière propre' },
  ].filter(c => c.active)

  if (candidates.length === 0) {
    return {
      ...buildNeutralResult(),
      conditions,
    }
  }

  // Best candidate by score
  const best = candidates.reduce((a, b) => a.score > b.score ? a : b)

  const confidence =
    best.score >= config.minScoreStrong ? 'strong' :
    best.score >= config.minScoreMedium ? 'medium' :
    best.score > 0 ? 'weak' : 'none'

  const signal: Signal = best.score >= config.minScoreMedium ? best.signal : 'none'

  // Theoretical entry / SL / TP
  const latestVWAP = getLatestVWAP(vwapPoints) ?? currentPrice
  const atr = estimateATR(klines, 14)

  let entryPrice = currentPrice
  let stopLoss = currentPrice
  let takeProfit = currentPrice

  if (best.signal === 'short') {
    entryPrice = currentPrice
    stopLoss = currentPrice + atr * 1.5
    takeProfit = currentPrice - atr * 2.5
  } else if (best.signal === 'long') {
    entryPrice = currentPrice
    stopLoss = currentPrice - atr * 1.5
    takeProfit = currentPrice + atr * 2.5
  }

  return {
    marketState: best.state,
    score: best.score,
    maxScore: MAX_POSSIBLE_SCORE,
    conditions,
    signal,
    confidence,
    description: best.desc,
    entryPrice,
    stopLoss,
    takeProfit,
  }
}

// ============================================================
// HELPERS
// ============================================================

function buildNeutralResult(): PatternResult {
  return {
    marketState: 'neutral',
    score: 0,
    maxScore: MAX_POSSIBLE_SCORE,
    conditions: {
      vwapBias: false,
      oiBuildUp: false,
      oiUnwind: false,
      oiStabilizing: false,
      cvdUp: false,
      cvdDown: false,
      cvdFlipBullish: false,
      cvdFlipBearish: false,
      impulseUp: false,
      impulseDown: false,
      consolidationBelowVWAP: false,
      consolidationAboveVWAP: false,
    },
    signal: 'none',
    confidence: 'none',
    description: 'Pas de setup détecté',
  }
}

/**
 * Estimate ATR (Average True Range) for SL/TP sizing
 */
function estimateATR(klines: Kline[], period: number = 14): number {
  if (klines.length < period) return klines[klines.length - 1]?.close * 0.005 ?? 100

  const recent = klines.slice(-period)
  const trueRanges = recent.map((k, i) => {
    if (i === 0) return k.high - k.low
    const prev = recent[i - 1]
    return Math.max(
      k.high - k.low,
      Math.abs(k.high - prev.close),
      Math.abs(k.low - prev.close)
    )
  })

  return trueRanges.reduce((a, b) => a + b, 0) / period
}
