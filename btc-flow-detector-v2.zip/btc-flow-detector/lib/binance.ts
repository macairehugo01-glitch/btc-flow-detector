/**
 * lib/binance.ts
 * All Binance Futures API calls — klines, aggTrades, open interest
 */

import type { Kline, AggTrade, OISnapshot, Timeframe } from '@/types'

const BINANCE_FUTURES_BASE = 'https://fapi.binance.com'
const SYMBOL = 'BTCUSDT'

// ============================================================
// KLINES
// ============================================================

/**
 * Fetch OHLCV klines from Binance Futures
 */
export async function fetchKlines(
  timeframe: Timeframe,
  limit: number = 200
): Promise<Kline[]> {
  const url = `${BINANCE_FUTURES_BASE}/fapi/v1/klines?symbol=${SYMBOL}&interval=${timeframe}&limit=${limit}`

  const res = await fetch(url, { next: { revalidate: 0 } })
  if (!res.ok) throw new Error(`Binance klines error: ${res.status}`)

  const data = await res.json()

  return data.map((k: unknown[]) => ({
    time: Math.floor((k[0] as number) / 1000),  // convert ms to seconds
    open: parseFloat(k[1] as string),
    high: parseFloat(k[2] as string),
    low: parseFloat(k[3] as string),
    close: parseFloat(k[4] as string),
    volume: parseFloat(k[5] as string),
    quoteVolume: parseFloat(k[7] as string),
  }))
}

// ============================================================
// AGG TRADES (for CVD reconstruction)
// ============================================================

/**
 * Fetch recent aggTrades for CVD calculation
 * isBuyerMaker=false => buyer is aggressive => buy volume
 * isBuyerMaker=true  => seller is aggressive => sell volume
 */
export async function fetchAggTrades(limit: number = 1000): Promise<AggTrade[]> {
  const url = `${BINANCE_FUTURES_BASE}/fapi/v1/aggTrades?symbol=${SYMBOL}&limit=${limit}`

  const res = await fetch(url, { next: { revalidate: 0 } })
  if (!res.ok) throw new Error(`Binance aggTrades error: ${res.status}`)

  const data = await res.json()

  return data.map((t: Record<string, unknown>) => ({
    time: t['T'] as number,            // trade time in ms
    price: parseFloat(t['p'] as string),
    quantity: parseFloat(t['q'] as string),
    isBuyerMaker: t['m'] as boolean,   // m=true means seller is aggressive
  }))
}

// ============================================================
// OPEN INTEREST
// ============================================================

/**
 * Fetch current open interest snapshot
 */
export async function fetchCurrentOI(): Promise<number> {
  const url = `${BINANCE_FUTURES_BASE}/fapi/v1/openInterest?symbol=${SYMBOL}`

  const res = await fetch(url, { next: { revalidate: 0 } })
  if (!res.ok) throw new Error(`Binance OI error: ${res.status}`)

  const data = await res.json()
  return parseFloat(data.openInterest)
}

/**
 * Fetch historical open interest (5m intervals, up to 500 bars)
 */
export async function fetchOIHistory(
  period: '5m' | '15m' | '30m' | '1h' = '5m',
  limit: number = 96  // ~8h of 5m bars
): Promise<OISnapshot[]> {
  const url = `${BINANCE_FUTURES_BASE}/futures/data/openInterestHist?symbol=${SYMBOL}&period=${period}&limit=${limit}`

  const res = await fetch(url, { next: { revalidate: 0 } })
  if (!res.ok) throw new Error(`Binance OI history error: ${res.status}`)

  const data = await res.json()

  const snapshots: OISnapshot[] = data.map((d: Record<string, unknown>) => ({
    time: Math.floor((d['timestamp'] as number) / 1000),
    openInterest: parseFloat(d['sumOpenInterest'] as string),
  }))

  // Calculate percentage change and trend
  for (let i = 1; i < snapshots.length; i++) {
    const prev = snapshots[i - 1].openInterest
    const curr = snapshots[i].openInterest
    const pct = ((curr - prev) / prev) * 100
    snapshots[i].changePercent = pct
    snapshots[i].trend = pct > 0.1 ? 'up' : pct < -0.1 ? 'down' : 'stable'
  }

  return snapshots
}

// ============================================================
// TICKER (real-time price)
// ============================================================

export async function fetchTicker(): Promise<{ price: number; change24h: number; volume24h: number }> {
  const url = `${BINANCE_FUTURES_BASE}/fapi/v1/ticker/24hr?symbol=${SYMBOL}`

  const res = await fetch(url, { next: { revalidate: 0 } })
  if (!res.ok) throw new Error(`Binance ticker error: ${res.status}`)

  const data = await res.json()
  return {
    price: parseFloat(data.lastPrice),
    change24h: parseFloat(data.priceChangePercent),
    volume24h: parseFloat(data.quoteVolume),
  }
}

// ============================================================
// FUNDING RATE (bonus)
// ============================================================

export async function fetchFundingRate(): Promise<{ rate: number; nextFundingTime: number } | null> {
  try {
    const url = `${BINANCE_FUTURES_BASE}/fapi/v1/premiumIndex?symbol=${SYMBOL}`
    const res = await fetch(url, { next: { revalidate: 0 } })
    if (!res.ok) return null

    const data = await res.json()
    return {
      rate: parseFloat(data.lastFundingRate) * 100,
      nextFundingTime: data.nextFundingTime,
    }
  } catch {
    return null
  }
}
