# BTC Flow Detector

Un moteur de lecture de flux de marché pour détecter automatiquement les setups de trading sur **BTCUSDT Perpetual Binance**, basé sur la combinaison **Prix + VWAP + Open Interest + CVD**.

---

## Setups détectés

| Setup | Signal | Logique |
|-------|--------|---------|
| **Majority Trap Short** | SHORT | Impulsion haussière → CVD flip baissier → OI unwind → prix sous VWAP → consolidation |
| **Bullish Reset Long** | LONG | Dump → OI unwind → CVD bas → reprise VWAP → OI rebuild → CVD flip haussier |
| **Continuation Long** | LONG | Prix > VWAP + OI build-up + CVD haussier + pullback propre |

---

## Stack technique

- **Frontend** : Next.js 14, React, TypeScript, Tailwind CSS
- **Charts** : TradingView Lightweight Charts v4
- **State** : Zustand (persistance locale des préférences)
- **Backend** : Next.js API Routes (intégré)
- **Base de données** : SQLite via better-sqlite3
- **Données** : Binance Futures API publique (pas d'API key requise)

---

## Installation rapide

### Prérequis

- Node.js 18+
- npm ou yarn

### 1. Cloner / copier le projet

```bash
cd btc-flow-detector
```

### 2. Installer les dépendances

```bash
npm install
```

> ⚠️ Si `better-sqlite3` échoue sur certaines plateformes, lancez :
> ```bash
> npm install --build-from-source better-sqlite3
> ```

### 3. Lancer en développement

```bash
npm run dev
```

Ouvrir [http://localhost:3000](http://localhost:3000)

### 4. Build production

```bash
npm run build
npm start
```

---

## Architecture du projet

```
btc-flow-detector/
├── app/
│   ├── api/
│   │   ├── market/route.ts      # Endpoint principal (klines + OI + CVD + pattern)
│   │   └── setups/route.ts      # Historique des setups SQLite
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx                 # Dashboard principal
│
├── components/
│   ├── charts/
│   │   ├── PriceChart.tsx       # Chandeliers + VWAP (lightweight-charts)
│   │   ├── OIChart.tsx          # Open Interest + delta histogram
│   │   └── CVDChart.tsx         # CVD cumulatif + delta
│   ├── panels/
│   │   ├── SignalPanel.tsx      # Signal Long/Short/Neutre + score
│   │   ├── ConditionsChecklist.tsx  # 12 conditions en temps réel
│   │   ├── OIStatsPanel.tsx     # Stats OI rapides
│   │   ├── SetupHistory.tsx     # Table des derniers setups
│   │   └── SettingsPanel.tsx    # Sliders de configuration
│   ├── Header.tsx
│   └── StatsBar.tsx
│
├── lib/
│   ├── binance.ts               # Appels API Binance (klines, aggTrades, OI, ticker)
│   ├── indicators.ts            # Calculs VWAP, CVD, OI analysis
│   ├── patterns.ts              # Moteur de détection de patterns
│   └── db.ts                   # SQLite (stockage historique)
│
├── store/
│   └── useMarketStore.ts        # Zustand store global
│
├── hooks/
│   └── useMarketData.ts         # Polling auto toutes les 10s
│
├── types/
│   └── index.ts                 # Types TypeScript complets
│
└── data/
    └── flow.db                  # SQLite créé automatiquement au premier démarrage
```

---

## Calculs clés

### VWAP
```
typical_price = (high + low + close) / 3
VWAP = Σ(typical_price × volume) / Σ(volume)
```
Session de 100 bougies par défaut, recalculée en continu.

### CVD (Cumulative Volume Delta)
```
aggTrade.isBuyerMaker = false → buy agressif → delta positif
aggTrade.isBuyerMaker = true  → sell agressif → delta négatif
delta_bar = Σ(buy) - Σ(sell)
CVD = Σ cumulatif des delta_bar
```

### Score de validation
| Condition | Points |
|-----------|--------|
| VWAP Bias | 2 |
| OI Build-Up | 2 |
| OI Unwind | 2 |
| CVD Up/Down | 2 |
| CVD Flip | 2 |
| OI Stabilisation | 1 |
| Impulsion | 1 |
| Consolidation | 1 |

- Score ≥ 6 → Signal **fort**
- Score 4-5 → Signal **moyen**
- Score < 4 → **Pas de signal**

---

## Configuration

Les seuils sont ajustables depuis l'interface (panneau Paramètres) :

| Paramètre | Défaut | Description |
|-----------|--------|-------------|
| OI Build-Up seuil | 0.5% | % variation OI pour considérer un build-up |
| Impulsion min | 0.3% | % mouvement prix pour considérer une impulsion |
| Consolidation max | 0.15% | Range maximum pour considérer une consolidation |
| Score fort | 6 | Score minimum signal fort |
| Score moyen | 4 | Score minimum signal moyen |

Deux modes disponibles :
- **Agressif** : conditions partielles suffisent (2/4 conditions requises)
- **Strict** : toutes les conditions requises doivent être remplies

---

## Données Binance utilisées

| Endpoint | Usage |
|----------|-------|
| `GET /fapi/v1/klines` | OHLCV pour chandeliers + VWAP |
| `GET /fapi/v1/aggTrades` | Reconstruction CVD |
| `GET /futures/data/openInterestHist` | Historique OI |
| `GET /fapi/v1/openInterest` | OI temps réel |
| `GET /fapi/v1/ticker/24hr` | Prix + volume |
| `GET /fapi/v1/premiumIndex` | Funding rate |

> Aucune clé API requise — données publiques uniquement.

---

## Évolutions futures

- [ ] Alertes Telegram sur signal fort
- [ ] Multi-assets (ETHUSDT, SOLUSDT, etc.)
- [ ] VWAP ancrée (Anchored VWAP)
- [ ] Backtest visuel des derniers signaux
- [ ] Watchlist multi-paires
- [ ] Migration SQLite → PostgreSQL
- [ ] Funding rate intégré aux conditions
- [ ] Export CSV de l'historique

---

## Disclaimer

Cet outil est un **aide à la décision**, pas un signal automatique à exécuter aveuglément. Les marchés crypto sont volatils. Faites toujours votre propre analyse. **Not financial advice.**
