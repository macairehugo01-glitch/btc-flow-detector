// ============================================================
// TYPES — BTC Flow Detector
// ============================================================

export interface Kline {
  time: number        // Unix timestamp (seconds)
  open: number
  high: number
  low: number
  close: number
  volume: number
  quoteVolume: number
}

export interface AggTrade {
  time: number        // Unix timestamp (ms)
  price: number
  quantity: number
  isBuyerMaker: boolean
}

export interface DeltaBar {
  time: number
  buyVolume: number
  sellVolume: number
  delta: number
  cvd: number         // cumulative value of delta
}

export interface OISnapshot {
  time: number
  openInterest: number
  changePercent?: number
  trend?: 'up' | 'down' | 'stable'
}

export interface VWAPPoint {
  time: number
  vwap: number
}

// ============================================================
// PATTERN ENGINE TYPES
// ============================================================

export interface MarketConditions {
  vwapBias: boolean           // price above VWAP
  oiBuildUp: boolean          // OI increasing significantly
  oiUnwind: boolean           // OI decreasing significantly
  oiStabilizing: boolean      // OI leveling off after move
  cvdUp: boolean              // CVD in uptrend
  cvdDown: boolean            // CVD in downtrend
  cvdFlipBullish: boolean     // CVD reversed from down to up
  cvdFlipBearish: boolean     // CVD reversed from up to down
  impulseUp: boolean          // recent strong bullish impulse
  impulseDown: boolean        // recent strong bearish impulse
  consolidationBelowVWAP: boolean
  consolidationAboveVWAP: boolean
}

export type MarketState =
  | 'majority_trap_short'
  | 'bullish_reset_long'
  | 'continuation_long'
  | 'neutral'

export type Signal = 'long' | 'short' | 'none'

export interface PatternResult {
  marketState: MarketState
  score: number
  maxScore: number
  conditions: MarketConditions
  signal: Signal
  confidence: 'strong' | 'medium' | 'weak' | 'none'
  description: string
  entryPrice?: number
  stopLoss?: number
  takeProfit?: number
}

// ============================================================
// STORED SETUP (SQLite)
// ============================================================

export interface StoredSetup {
  id: number
  timestamp: number
  marketState: MarketState
  signal: Signal
  score: number
  confidence: string
  entryPrice: number
  stopLoss: number
  takeProfit: number
  conditions: string  // JSON stringified MarketConditions
}

// ============================================================
// API RESPONSES
// ============================================================

export interface MarketDataResponse {
  klines: Kline[]
  vwap: VWAPPoint[]
  cvd: DeltaBar[]
  oi: OISnapshot[]
  pattern: PatternResult
  lastUpdate: number
  timeframe: Timeframe
}

export type Timeframe = '1m' | '5m' | '15m' | '1h'

// ============================================================
// SETTINGS / CONFIG
// ============================================================

export interface ThresholdConfig {
  oiBuildUpThresholdPct: number    // % OI increase to count as buildup (default: 0.5)
  oiUnwindThresholdPct: number     // % OI decrease to count as unwind (default: -0.5)
  cvdFlipBars: number              // bars to confirm CVD flip (default: 3)
  impulseMinPct: number            // min % price move to count as impulse (default: 0.3)
  consolidationMaxPct: number      // max % range to count as consolidation (default: 0.15)
  minScoreStrong: number           // min score for strong signal (default: 6)
  minScoreMedium: number           // min score for medium signal (default: 4)
  mode: 'strict' | 'aggressive'
}

export const DEFAULT_THRESHOLDS: ThresholdConfig = {
  oiBuildUpThresholdPct: 0.5,
  oiUnwindThresholdPct: -0.5,
  cvdFlipBars: 3,
  impulseMinPct: 0.3,
  consolidationMaxPct: 0.15,
  minScoreStrong: 6,
  minScoreMedium: 4,
  mode: 'aggressive',
}
